import Foundation

struct Wrapper: Codable {
    let data: Container
}

