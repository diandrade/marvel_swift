import SwiftUI

struct DescriptionView: View {
    var body: some View {
        Text("Tela de descricao do personagem")
    }
}

