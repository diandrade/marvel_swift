import Foundation

struct Container: Codable {
    let results: [Characters]
}

