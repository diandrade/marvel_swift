import SwiftUI

struct CharacterRow: View {
    let nome: String
    
    var body: some View {
        Text(nome)
    }
}

