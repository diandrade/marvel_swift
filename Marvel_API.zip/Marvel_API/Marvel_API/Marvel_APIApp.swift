//
//  Marvel_APIApp.swift
//  Marvel_API
//
//  Created by iOSLab on 29/03/25.
//

import SwiftUI

@main
struct Marvel_APIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
